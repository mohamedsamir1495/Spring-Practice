create
    definer = root@`%` procedure GetAllProducts()
BEGIN
	SELECT *  FROM product;
END;

